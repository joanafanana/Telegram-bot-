import telebot

token='7328237348:AAEtKrB_QY8KPp-9rDG0FGUvW7Cjg3lnMaQ'

bot = telebot.TeleBot(token)

@bot.message_handler(commands=['start'])
def start_message(message):
  bot.send_message(message.chat.id,"Привет ✌️ ")

@bot.message_handler(content_types=['text'])
def new_message(message):
    if message.text== 'hello':
      bot.send_message(message.chat.id,"what's up?!")
    elif message.text== "send cat":
     bot.send_photo(message.chat.id, photo= "https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1")
    elif message.text== "send dog":
     bot.send_photo(message.chat.id, photo= "https://be.chewy.com/dog-breed/pembroke-welsh-corgi")
    elif message.text== "send meme":
      bot.send_sticker(message.chat.id, "CAACAgQAAxkBAAEK3V5laTccvV3Jw1PEHD59CukXCtTsxAACtAAD7F0yD8M5XP2ymNSBMwQ")

    elif message.text== "/gif":
      bot.send_animation(message.chat.id,animation= "https://media.giphy.com/media/mlvseq9yvZhba/giphy.gif")
    else:
      bot.send_message(message.chat.id,"And hello to you too!")
    



bot.polling(none_stop = True)